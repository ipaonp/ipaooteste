<?php
echo Yii::t("default","Sorry but you don't have access this page.");