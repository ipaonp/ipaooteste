<?php
$this->renderPartial('/front/thermal_receipt',array(
   'order_id'=>$_GET['id']
));