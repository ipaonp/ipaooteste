

<p class="uk-text-danger">
<i style="color:red;" class="fa fa-exclamation-triangle"></i> <?php echo $msg?>
</p>